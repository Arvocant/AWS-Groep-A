import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { IRegister } from './interfaces';

@Injectable({
  providedIn: 'root'
})
export class ZwembadServiceService {
Name:string="";
LidNr:string="";
ZwembadNaam:string="";
ZwemUur:string="";
  constructor(private http: HttpClient) { }

  GetZwembaden(){
    return this.http.get<IZwembaden>("http://localhost:3000/zwembaden")
              .toPromise();
  }
  GetUren(){
    return this.http.get<IUren>("http://localhost:3000/uren")
              .toPromise();
  }
}

export interface IZwembaden {
  id: number;
  name: string;
}

export interface IUren {
  zwembadId: number;
  uren: string[];
}

export interface IzwembadInfo {
  zwembaden: IZwembaden[];
  uren: IUren[];
}

