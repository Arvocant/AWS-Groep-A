
export interface IRegister {
    _id: string;
    Name: string;
    MemberId: string;
    PoolName: string;
    Timeslot: string;
  }
  