import { TestBed } from '@angular/core/testing';

import { ZwembadServiceService } from './zwembad-service.service';

describe('ZwembadServiceService', () => {
  let service: ZwembadServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ZwembadServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
