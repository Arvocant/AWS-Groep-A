import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule} from '@angular/common/http';

import { AppComponent } from './app.component';
import { Step1Component } from './step1/step1.component';

import { NavigationComponent } from './navigation/navigation.component';
import { RouterModule, Routes } from '@angular/router';
import { from } from 'rxjs';
const routes: Routes = [
  {
    path:"step1",
    component: Step1Component
  },
  {
    path:'**',
    component: Step1Component
  },
  {
    path:"",
    redirectTo:"step1", pathMatch:'full'
  }
  ];
@NgModule({
  declarations: [
    AppComponent,
    Step1Component,

    NavigationComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
