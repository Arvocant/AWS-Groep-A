import { Component, OnInit } from '@angular/core';
import { ZwembadServiceService } from '../Services/zwembad-service.service';

@Component({
  selector: 'app-step1',
  templateUrl: './step1.component.html',
  styleUrls: ['./step1.component.css']
})
export class Step1Component implements OnInit {
Name: string;
LidNr:string;
  constructor(private svc: ZwembadServiceService) {
    this.Name=svc.Name;
    this.LidNr=svc.LidNr;
   }

  ngOnInit(): void {
    
  }
  SaveName(name:string){
    this.svc.Name=name;
  }
  SaveNr(nr:string){
    this.svc.LidNr=nr;
  }

}
